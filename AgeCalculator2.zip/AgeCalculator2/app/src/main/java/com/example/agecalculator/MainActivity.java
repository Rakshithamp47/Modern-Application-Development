package com.example.agecalculator;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private ImageView imageview1;
    private EditText edittext1;
    private EditText edittext2;
    private Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edittext1 = findViewById(R.id.edittext1);
        imageview1 = findViewById(R.id.imageview1);
        edittext2 = findViewById(R.id.edittext2);
        button2 = findViewById(R.id.button2);

        imageview1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(imageview1);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText("");
                edittext2.setText("");
            }
        });
    }


    private void showDatePickerDialog(ImageView imageview1) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getFragmentManager(), "datePicker");
    }

    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        Calendar now = Calendar.getInstance();

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            int y = now.get(Calendar.YEAR);
            int m = now.get(Calendar.MONTH);
            int d = now.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, y, m, d);
        }

        @RequiresApi(api = Build.VERSION_CODES.M)
        public void onDateSet(DatePicker view, int year, int month, int day) {
            int mon = month + 1;
            Calendar birthDay = Calendar.getInstance();
            String date = day + "/" + mon + "/" + year;
            EditText edittext21 = getActivity().findViewById(R.id.edittext1);
            EditText edittext22 = getActivity().findViewById(R.id.edittext2);
            edittext21.setText(date);
            birthDay.set(Calendar.YEAR, year);
            birthDay.set(Calendar.MONTH, month);
            birthDay.set(Calendar.DAY_OF_MONTH, day);
            double diff = (long) (now.getTimeInMillis() - birthDay.getTimeInMillis());
            if (diff < 0) {
                Toast.makeText(getContext(), "Its an INVALID Date", Toast.LENGTH_SHORT).show();
                edittext22.setText("");
            } else {
                int years = now.get(Calendar.YEAR) - birthDay.get(Calendar.YEAR);
                int currMonth = now.get(Calendar.MONTH) + 1;
                int birthMonth = birthDay.get(Calendar.MONTH) + 1;
                //for calculating months
                int months = currMonth - birthMonth;
                if (months < 0) {
                    years--;
                    months = 12 - birthMonth + currMonth;
                    if (now.get(Calendar.DATE) < birthDay.get(Calendar.DATE))
                        months--;
                } else if (months == 0 && now.get(Calendar.DATE) < birthDay.get(Calendar.DATE)) {
                    years--;
                    months = 11;
                }
                //for calculating days
                int days = 0;
                if (now.get(Calendar.DATE) > birthDay.get(Calendar.DATE))
                    days = now.get(Calendar.DATE) - birthDay.get(Calendar.DATE);
                else if (now.get(Calendar.DATE) < birthDay.get(Calendar.DATE)) {
                    int today = now.get(Calendar.DAY_OF_MONTH);
                    months--;
                    days = now.getActualMaximum(Calendar.DAY_OF_MONTH) - birthDay.get(Calendar.DAY_OF_MONTH) + today;
                } else {
                    days = 0;
                    if (months == 12) {
                        years++;
                        months = 0;
                    }
                }
                // display
                edittext22.setText(years + " years, " + months + " months, " + days + " days");
            }
        }
    }
}